DARK EARTH PATCH

DarkEarthPatch.EXE is a self-extracting ZIP archive. Double-click on the DarkEarthPatch.EXE icon 
to open the extractor.

In the text box under "UNZIP TO FOLDER:" is the default directory for Dark Earth.  If 
you have installed to a different location than the one given 
(C:\Program Files\Microprose\Dark Earth,) edit that line to reflect the 
appropriate location.

Then press the "UNZIP" button.  It should ask if you want to overwrite the 
existing version of DKEV.EXE.  Answer yes.  Note that if you don't not get this 
warning message, you are probably installing to the wrong directory.  See the 
above paragraph.

This version of the main executable (DKEV.EXE) adds expanded error messaging for 
troubleshooting purposes.  It fixes the problem of "Fatal Error 4" (file not
found) occurring on some people's systems who have non-contiguous drive 
designations. It also contains an option for forcing 256-color mode for video 
cards and chipsets which cannot handle the 32K-color version (e.g. some laptops) 
which can cause error 8 messages.  If you are getting error 9, you may have a 
video card with under two megabytes of memory, which is beneath the game 
specifications.

Fatal error 4 means that a file the program is looking for is not where it was 
expected to be.  This patch will fix most of those, but there are a few other 
possible causes, according to Kalisto:

Ifyou  have more than 5 hard disks or partitions and installed the game on a 
hard drive past the fifth one, as H: or more, C: to G: being other hard disks. 

If you have a CD-R drive before CD-Rom drive, or are trying to run the game from 
another CD drive than the first one.  Try the special diagnostic version 
attached with this email and this should go away - unless you actually have more 
than 5 CD drives and you're trying to read from a drive past the first 5 ones.

People who have illegal pirate copies will also get Error 4.  Believe it or not, 
some of these people actually contact us for technical support!!!

*****
Another possible (though rare) cause of Error 4 is if the CD device has been 
labeled "CD1." The name of your CD Drive (or any device) MUST NOT be called " 
CD1 ."  The cause of a CD being thusly named would be in the loading of DOS 
real-mode drivers in the CONFIG.SYS file.

(Note: Users who do not run any Ms-Dos programs need not load these real-mode 
drivers, as they are used only for programs which run exclusively in MS-DOS 
mode.  They are included on systems to permit backward-compatiblity for Dos 
applications.)

To change the name of your CD Rom driver:

1/ Using the Windows NOTEPAD program open the file called CONFIG.SYS.

This file is located at the root of your HardDisk. If you cannot see
it, change the view option (in the explorer), in the display tab, and
select to show all the files.

2/ In the CONFIG.SYS file, locate the line concerning your CD Drive.
The line looks something like this:

DEVICEHIGH=C:\<foldername>\<drivername>.SYS /D:CD1

(It might just say DEVICE= instead of DEVEICEHIGH= which is OK. Where 
you see <foldername> and <drivername> above will be different from 
system to system.  The part of the line we're focusing on is where it 
says D:/CD1 - that's where the CD unit is named.

3/ Change the name of the CD. An appropriate name could be MSC0001.  You 
could name it anything you want, as long as it isn't CD1.  So now our 
line looks like this:

DEVICEHIGH=C:\foldername\<drivername>.SYS /D:MSC0001

4/ Save the CONFIG.SYS file.

5/ If you changed the /D:CD1 parameter as stated above, you must also 
change that same parameter in the line that loads the dos extentions, 
located in either or both of the following files:  AUTOEXEC.BAT (located 
in the root of your C: drive; if you don't see a reference to MSCDEX.EXE 
that is OK and actually preferrable) and/or DOSSTART.BAT located in your 
WINDOWS folder.

6/ Open the file using Notepad as described above, locate the line 
concerning the CD Driver. The line should be as follows:

C:\<foldername>\MSCDEX.EXE /D:CD1

7/ Again, change the name of the CD. Set the same name you used in the
CONFIG.SYS

C:\foldername\MSCDEX.EXE /D:MSCD0001

8/ Save the file.

9/ To make the change operational, you must reboot your computer.

If your CD has a short spindown time (the time it takes for the unit to go into 
"sleep mode," the game may be timing out waiting for the CD to "wake up: and get 
back up to speed.  Contact your CD manufacturer to see if this is the case with 
yours, and if they have a fix.  There is a shareware utility on the web called
"spindown" which will allow you to change the spindown time of yourCD ROM, but 
it's not real user-friendly and is recommended for technically advanced users 
only.

*****

